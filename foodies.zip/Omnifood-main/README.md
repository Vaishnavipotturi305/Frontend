# Omnifood

Landing page website for a fictional food delivery company  called **"OMNIFOOD"** build using modern **HTML5** , **CSS3** ,  and **JAVASCRIPT**.
![Live project](project.png)

*This project is a part of udemy course taught by Jonas Schmedtmann*
